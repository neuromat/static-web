load data
scatterhist(x(1,:),x(2,:))
c=emgm(x,3);
figure,gscatter(x(1,:),x(2,:),c,[],[],7)